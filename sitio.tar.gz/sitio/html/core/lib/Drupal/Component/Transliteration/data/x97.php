<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'xu', 'ji', 'mu', 'chen', 'xiao', 'zha', 'ting', 'zhen', 'pei', 'mei', 'ling', 'qi', 'zhou', 'huo', 'sha', 'fei',
  0x10 => 'hong', 'zhan', 'yin', 'ni', 'zhu', 'tun', 'lin', 'ling', 'dong', 'ying', 'wu', 'ling', 'shuang', 'ling', 'xia', 'hong',
  0x20 => 'yin', 'mai', 'mai', 'yun', 'liu', 'meng', 'bin', 'wu', 'wei', 'kuo', 'yin', 'xi', 'yi', 'ai', 'dan', 'teng',
  0x30 => 'san', 'yu', 'lu', 'long', 'dai', 'ji', 'pang', 'yang', 'ba', 'pi', 'wei', 'feng', 'xi', 'ji', 'mai', 'meng',
  0x40 => 'meng', 'lei', 'li', 'huo', 'ai', 'fei', 'dai', 'long', 'ling', 'ai', 'feng', 'li', 'bao', 'he', 'he', 'he',
  0x50 => 'bing', 'qing', 'qing', 'jing', 'tian', 'zhen', 'jing', 'cheng', 'qing', 'jing', 'jing', 'dian', 'jing', 'tian', 'fei', 'fei',
  0x60 => 'kao', 'mi', 'mian', 'mian', 'bao', 'ye', 'tian', 'hui', 'ye', 'ge', 'ding', 'cha', 'qian', 'ren', 'di', 'du',
  0x70 => 'wu', 'ren', 'qin', 'jin', 'xue', 'niu', 'ba', 'yin', 'sa', 'na', 'mo', 'zu', 'da', 'ban', 'yi', 'yao',
  0x80 => 'tao', 'bei', 'jia', 'hong', 'pao', 'yang', 'bing', 'yin', 'ge', 'tao', 'jie', 'xie', 'an', 'an', 'hen', 'gong',
  0x90 => 'qia', 'da', 'qiao', 'ting', 'man', 'ying', 'sui', 'tiao', 'qiao', 'xuan', 'kong', 'beng', 'ta', 'shang', 'bing', 'kuo',
  0xA0 => 'ju', 'la', 'xie', 'rou', 'bang', 'eng', 'qiu', 'qiu', 'he', 'xiao', 'mu', 'ju', 'jian', 'bian', 'di', 'jian',
  0xB0 => 'wen', 'tao', 'gou', 'ta', 'bei', 'xie', 'pan', 'ge', 'bi', 'kuo', 'tang', 'lou', 'gui', 'qiao', 'xue', 'ji',
  0xC0 => 'jian', 'jiang', 'chan', 'da', 'hu', 'xian', 'qian', 'du', 'wa', 'jian', 'lan', 'wei', 'ren', 'fu', 'mei', 'quan',
  0xD0 => 'ge', 'wei', 'qiao', 'han', 'chang', 'kuo', 'rou', 'yun', 'she', 'wei', 'ge', 'bai', 'tao', 'gou', 'yun', 'gao',
  0xE0 => 'bi', 'wei', 'sui', 'du', 'wa', 'du', 'wei', 'ren', 'fu', 'han', 'wei', 'yun', 'tao', 'jiu', 'jiu', 'xian',
  0xF0 => 'xie', 'xian', 'ji', 'yin', 'za', 'yun', 'shao', 'le', 'peng', 'huang', 'ying', 'yun', 'peng', 'an', 'yin', 'xiang',
];
